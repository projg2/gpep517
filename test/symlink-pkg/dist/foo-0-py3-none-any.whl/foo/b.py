"""b module"""
