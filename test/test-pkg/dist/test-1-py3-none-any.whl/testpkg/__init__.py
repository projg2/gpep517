"""A test package"""

def entry_point():
    print("this is entry point")
